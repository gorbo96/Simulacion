from mimetypes import init
from tkinter import * 
import collections
import random
import simpy

class Simulacion:
  ventana=Tk()
  frame=Frame(ventana)
  WIDTH, HEIGHT = 1020, 720
  canvas=Canvas(ventana, width=WIDTH, height=HEIGHT, bg = "white")

  ventana.title('Simulacion Cinema')
  ventana.resizable(False, False)
  ventana.config(bg="#fff")
  frame.pack(side=TOP, expand = False)
  canvas.pack(side=TOP, expand = False)

  NUM_BOLETO = 70
  TIEMPO_SIMULACION = 120  

  titulo1=canvas.create_text(95, 30, text="Conjuro 3", fill="black", font=('Helvetica 30 bold'))
  titulo2=canvas.create_text(500, 30, text="Rapidos y Furiosos 10", fill="black", font=('Helvetica 30 bold'))
  titulo3=canvas.create_text(900, 30, text="Pulp Fictions", fill="black", font=('Helvetica 30 bold'))

  contador1=canvas.create_text(95, 100, text=NUM_BOLETO, fill="black", font=('Helvetica 40 bold'))
  contador2=canvas.create_text(500, 100, text=NUM_BOLETO, fill="black", font=('Helvetica 40 bold'))
  contador3=canvas.create_text(900, 100, text=NUM_BOLETO, fill="black", font=('Helvetica 40 bold'))

  agotado1=canvas.create_text(100, 160, text="Agotado a: 0.0", fill="black", font=('Helvetica 20 bold'))
  agotado2=canvas.create_text(500, 160, text="Agotado a: 0.0", fill="black", font=('Helvetica 20 bold'))
  agotado3=canvas.create_text(900, 160, text="Agotado a: 0.0", fill="black", font=('Helvetica 20 bold'))

  resagados1=canvas.create_text(100, 550, text="Resagados:", fill="black", font=('Helvetica 20 bold'))
  resagados2=canvas.create_text(500, 550, text="Resagados:", fill="black", font=('Helvetica 20 bold'))
  resagados3=canvas.create_text(900, 550, text="Resagados:", fill="black", font=('Helvetica 20 bold'))

  resagadosNm1=canvas.create_text(100, 600, text="0", fill="black", font=('Helvetica 40 bold'))
  resagadosNm2=canvas.create_text(500, 600, text="0", fill="black", font=('Helvetica 40 bold'))
  resagadosNm3=canvas.create_text(900, 600, text="0", fill="black", font=('Helvetica 40 bold'))

  img=PhotoImage(file="32441.png")
  personas=canvas.create_image(10, 250, image=img, anchor="nw")

  imgE=PhotoImage(file="empleado.png")
  empleado=canvas.create_image(750, 200, image=imgE, anchor="nw")

  mensajeCliente=canvas.create_text(350, 350, text="Queremos 0 entradas para\nRapidos y Furiosos 10", fill="black", font=('Helvetica 15 bold'))
  mensajeEmpleado=canvas.create_text(650, 350, text="Agotado", fill="black", font=('Helvetica 15 bold'))

  tiempo=canvas.create_text(160, 700, text="Tiempo: 0.0", fill="black", font=('Helvetica 35 bold'))

  def cambiar_mensaje_cliente(self,env,boletos,funcion):
    self.canvas.delete(self.mensajeCliente)    
    self.mensajeCliente=self.canvas.create_text(350, 350, text="Queremos "+str(boletos)+" entradas para\n"+ str(funcion)+"\n Llegada : "+str(round(env.now,1)), fill="black", font=('Helvetica 15 bold'))
    self.canvas.update()

  def cambio_mensaje_empleado(self,env,caso):
    self.canvas.delete(self.mensajeEmpleado) 
    if(caso==1):
      self.mensajeEmpleado=self.canvas.create_text(650, 350, text="Agotado\nFin atencion: "+str(round(env.now,1)), fill="black", font=('Helvetica 15 bold'))
    if(caso==2):
      self.mensajeEmpleado=self.canvas.create_text(650, 350, text="No tenemos esa cantidad\nFin atencion: "+str(round(env.now,1)), fill="black", font=('Helvetica 15 bold'))
    if (caso==3):
      self.mensajeEmpleado=self.canvas.create_text(650, 350, text="Por supuesto\nFin atencion: "+str(round(env.now,1)), fill="black", font=('Helvetica 15 bold'))
    self.canvas.update

  def disminuir_stock(self,funcion,boletos):
    if(funcion=="Conjuro 3"):
      self.canvas.delete(self.contador1)
      self.contador1=self.canvas.create_text(95, 100, text=str(boletos), fill="black", font=('Helvetica 40 bold'))
    if(funcion=='Rapidos y Furiosos 10'):
      self.canvas.delete(self.contador2)
      self.contador2=self.canvas.create_text(500, 100, text=str(boletos), fill="black", font=('Helvetica 40 bold'))
    if(funcion=='Pulp Fictions'):
      self.canvas.delete(self.contador3)
      self.contador3=self.canvas.create_text(900, 100, text=str(boletos), fill="black", font=('Helvetica 40 bold'))
    self.canvas.update()

  def aumentar_resagados(self,funcion,resagados):
    if(funcion=="Conjuro 3"):
      self.canvas.delete(self.resagadosNm1)
      self.resagadosNm1=self.canvas.create_text(100, 600, text=str(resagados), fill="black", font=('Helvetica 40 bold'))
    if(funcion=='Rapidos y Furiosos 10'):
      self.canvas.delete(self.resagadosNm2)
      self.resagadosNm2=self.canvas.create_text(500, 600, text=str(resagados), fill="black", font=('Helvetica 40 bold'))
    if(funcion=='Pulp Fictions'):
      self.canvas.delete(self.resagadosNm3)
      self.resagadosNm3=self.canvas.create_text(900, 600, text=str(resagados), fill="black", font=('Helvetica 40 bold'))
    self.canvas.update()
  
  def registrar_hora_termino(self,funcion,hora):
    if(funcion=="Conjuro 3"):
      self.canvas.delete(self.agotado1)
      self.agotado1=self.canvas.create_text(100, 160, text="Agotado a: "+str(round(hora,1)), fill="black", font=('Helvetica 20 bold'))
    if(funcion=='Rapidos y Furiosos 10'):
      self.canvas.delete(self.agotado2)
      self.agotado2=self.canvas.create_text(500, 160, text="Agotado a: "+str(round(hora,1)), fill="black", font=('Helvetica 20 bold'))
    if(funcion=='Pulp Fictions'):
      self.canvas.delete(self.agotado3)
      self.agotado3=self.canvas.create_text(900, 160, text="Agotado a: "+str(round(hora,1)), fill="black", font=('Helvetica 20 bold'))
    self.canvas.update()

  def ventaBoletos(self,env, num_boletos, pelicula, teatro):
    with teatro.contador.request() as turno:      
      resultado = yield turno | teatro.sold_out[pelicula]
      self.cambiar_mensaje_cliente(env,num_boletos,pelicula)
      if turno not in resultado:
        teatro.num_renegados[pelicula] += 1
        self.cambio_mensaje_empleado(env,1)
        self.aumentar_resagados(pelicula,teatro.num_renegados[pelicula])
        return
      if teatro.num_boletos[pelicula] < num_boletos:
        yield env.timeout(0.5)
        self.cambio_mensaje_empleado(env,2)
        return
      self.cambio_mensaje_empleado(env,3)
      teatro.num_boletos[pelicula] -= num_boletos
      self.disminuir_stock(pelicula,teatro.num_boletos[pelicula])
      if teatro.num_boletos[pelicula] < 2:
        teatro.sold_out[pelicula].succeed()
        teatro.tiempo_agotado[pelicula] = env.now
        teatro.num_boletos[pelicula] = 0
        self.registrar_hora_termino(pelicula,env.now)
      yield env.timeout(1)

  def llegadaClientes(self,env, teatro):  
    while True:      
      yield env.timeout(random.expovariate(1/0.5))    
      pelicula = random.choices(teatro.peliculas, teatro.probabilidad, k=1)    
      num_boletos = random.randint(1, 6)
      if teatro.num_boletos[pelicula[0]]:
        env.process(self.ventaBoletos(env, num_boletos, pelicula[0], teatro))

  def proceso_reloj(self,env):
    while True:
      yield env.timeout(0.001)        
      self.canvas.delete(self.tiempo)
      self.tiempo=self.canvas.create_text(160, 700, text="Tiempo: "+str(round(env.now,1)), fill="black", font=('Helvetica 35 bold'))
      self.canvas.update()

  def __init__(self):    
    print('Teatro Carlos Crespi - UPS')    
    Teatro = collections.namedtuple('Teatro', 'contador, peliculas, probabilidad, num_boletos, sold_out, tiempo_agotado, num_renegados')
    env = simpy.Environment()
    contador = simpy.Resource(env,capacity=1)
    peliculas = ['Conjuro 3', 'Rapidos y Furiosos 10', 'Pulp Fictions']
    probabilidad=[0.3, 0.3, 0.4]
    num_boletos = {pelicula: self.NUM_BOLETO for pelicula in peliculas}
    sold_out = {pelicula: env.event() for pelicula in peliculas}
    tiempo_agotado = {pelicula: None for pelicula in peliculas}
    num_renegados = {pelicula: 0 for pelicula in peliculas}
    teatro = Teatro(contador, peliculas, probabilidad, num_boletos, sold_out, tiempo_agotado, num_renegados)
    
    env.process(self.llegadaClientes(env, teatro))
    env.process(self.proceso_reloj(env))
    env.run(until=self.TIEMPO_SIMULACION)  
    for pelicula in peliculas:
      if teatro.sold_out[pelicula]:
        print('Pelicula: %s se agoto en el tiempo %.1f despues de salir a la venta' %(pelicula, teatro.tiempo_agotado[pelicula]))
        print('Numero de personas que salieron de la fila/renegados %s' %teatro.num_renegados[pelicula])  
    self.ventana.mainloop()

if __name__ == '__main__':
  print("inicio simulacion")
  proceso=Simulacion()